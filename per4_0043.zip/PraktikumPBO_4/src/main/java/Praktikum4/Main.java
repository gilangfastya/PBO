/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum4;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Pekerja pekerja1 = new Pekerja("Cahyo wicaksono", 28, "Progamer", 5000000);

        System.out.println("=== Data Pekerja Awal ===");
        System.out.println(pekerja1);

        pekerja1.setNama("Cahyo wijaya");

        System.out.println("\n=== Data Pekerja Setelah Nama Diubah ===");
        System.out.println(pekerja1);

        pekerja1.pekerjaan = "Dsainer";
        System.out.println("\nPekerjaan telah diubah ke: " + pekerja1.pekerjaan);
    }
}
