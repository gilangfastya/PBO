/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package oop.praktikumpbo_4;

import Praktikum4.Kendaraan;
import Praktikum4.Mobil;

/**
 *
 * @author acer
 */
public class PraktikumPBO_4 {

    public static void main(String[] args) {
        Kendaraan mobil = new Kendaraan("Toyota Avanza", 180, "Bensin");
        mobil.tampilkanInfoKendaraan();

        mobil.setNama("Toyota Innova");
        System.out.println("\nSetelah nama diubah:");
        System.out.println("Nama Kendaraan: " + mobil.getNama());

        System.out.println("\n----------------------------------\n");

        Mobil mobilBaru = new Mobil("Honda Jazz", 160, "Bensin", 4);
        mobilBaru.tampilkanInfoKendaraan();
        mobilBaru.tampilkanInfoMobil();
    }
}
