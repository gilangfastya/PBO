/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum_5_hewan;

/**
 *
 * @author acer
 */
public class MainHewan {
    public static void main(String[] args) {
        Kucing kucing = new Kucing();
        kucing.nama = "Fleky";
        kucing.jenis = "Kucing Garangan";
        kucing.tampilkanInfo();

        Anjing anjing = new Anjing();
        anjing.nama = "Floky";
        anjing.jenis = "Anjing Galak";
        anjing.tampilkanInfo();
    }
}