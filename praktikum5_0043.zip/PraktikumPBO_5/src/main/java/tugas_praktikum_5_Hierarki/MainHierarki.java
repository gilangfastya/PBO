/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum_5_Hierarki;

/**
 *
 * @author acer
 */
public class MainHierarki {
    public static void main(String[] args) {
        MobilBaru mobil = new MobilBaru("Rx-7", 200, 4, 2);
        mobil.tampilkanInfo();

        SepedaMotorBaru motor = new SepedaMotorBaru("Ninja", 180, 2, "4-tak");
        motor.tampilkanInfo();
    }
}