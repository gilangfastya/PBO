/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas_praktikum6;

/**
 *
 * @author xiuviu
 */
public class Main {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja();

        keranjang.tambahProduk(new Buku("psychology of money", 250000));
        keranjang.tambahProduk(new Elektronik("Google pixel 10 pro", 8500000));
        keranjang.tambahProduk(new Pakaian("Lari Adidas", 340000));

        keranjang.tampilkanDaftarBelanja();
        System.out.println("Total belanja setelah diskon: " + keranjang.hitungTotalSetelahDiskon());
    }
}