/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_6;

/**
 *
 * @author xiuviu
 */
public class PraktikumPBO_6 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
