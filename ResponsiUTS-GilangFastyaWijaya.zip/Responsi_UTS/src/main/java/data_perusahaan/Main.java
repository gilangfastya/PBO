/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package data_perusahaan;

/**
 *
 * @author xiuviu
 */
public class Main {
    public static void main(String[] args) {
        
        Produk produk1 = new Elektronik("Laptop Asus", 15000000, 2);
        Produk produk2 = new Makanan("Ayam Geprek", 15000, "2026-10-14");
        Pegawai pegawai1 = new PegawaiTetap("Gilang", 5200000, 1100000);
        Pegawai pegawai2 = new PegawaiKontrak("Jaya", 2500000, 8);
 
        System.out.println("1. Output Produk :");
        produk1.tampilkanInfo();
        System.out.println();
        
        System.out.println("2. Output Pegawai :");
        pegawai1.tampilkanInfo();
        System.out.println();
        
        System.out.println("3. Output Polimmorfisme :");
        produk2.tampilkanInfo();
        System.out.println();
        pegawai2.tampilkanInfo();
    }
}
 