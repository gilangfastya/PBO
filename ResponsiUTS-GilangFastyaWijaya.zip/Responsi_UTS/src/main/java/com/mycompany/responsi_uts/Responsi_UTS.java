/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.responsi_uts;

/**
 *
 * @author xiuviu
 */
public class Responsi_UTS {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
