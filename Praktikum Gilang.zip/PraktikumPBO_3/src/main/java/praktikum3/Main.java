/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum3;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Hewan serigala = new Hewan("Floky", 3);
        serigala.suara();
        serigala.info();
        
        Hewan harimau = new Hewan("Tiger", 2);
        harimau.berlari();
    }
}
