/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package oop.praktikumpbo_3;

/**
 *
 * @author acer
 */
public class PraktikumPBO_3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
