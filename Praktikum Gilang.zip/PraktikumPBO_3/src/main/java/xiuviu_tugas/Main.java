/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xiuviu_tugas;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        Mobil mobil1 = new Mobil("Toyota", "Avanza", 2022, "Hitam");
        Mobil mobil2 = new Mobil("Honda", "Civic", 2023, "Merah");
        
        System.out.println("MOBIL 1");
        mobil1.displayInfo();
        mobil1.startEngine();

        System.out.println();
        System.out.println("MOBIL 2");
        mobil2.displayInfo();
        mobil2.startEngine();

        System.out.println();
        mobil1.ubahWarna("Putih");
        System.out.println("Warna diubah");
        mobil1.displayInfo();
    }
}